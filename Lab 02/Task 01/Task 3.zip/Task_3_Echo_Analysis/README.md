# Task 3: Real-Time Echocardiogram Video Analysis

Pipeline (see `realtime_echo.ipynb`):

1. `cv2.VideoCapture('data/sample_echo.mp4')` reads the ultrasound clip frame by frame in a `while` loop.
2. Per frame: histogram equalization -> `COLORMAP_JET` -> gray-world color balance -> logarithmic transform -> power-law (gamma=0.7) transform.
3. Raw and enhanced frames are concatenated with `np.hstack` and shown live with `cv2.imshow`.
4. Press `q` to stop the loop early; the window closes via `cv2.destroyAllWindows()`.

Note: `cv2.imshow` opens a native GUI window and requires a display — run this notebook/script locally (not on a headless server) for the live side-by-side view. A sample comparison frame is also saved to `output/sample_comparison_frame.png` for grading evidence without needing to run the live loop.

Source dataset (swap in real sample clip before final submission): Stanford EchoNet-Dynamic Dataset — https://www.kaggle.com/datasets/manojkumarcs28/echonet-dynamic-by-stanford-university
