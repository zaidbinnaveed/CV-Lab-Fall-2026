# Task 2: Multi-Modal Cardiac Image Fusion

Pipeline (see `modal_fusion.ipynb`):

1. Load `data/sample_ct.png` and `data/sample_mri.png` (aligned grayscale slices).
2. Histogram-equalize each independently.
3. Colorize: CT -> `COLORMAP_BONE`, MRI -> `COLORMAP_JET`.
4. Fuse with `cv2.addWeighted(ct_color, 0.7, mri_color, 0.3, 0)` — heavier weight on CT to preserve sharp anatomical edges, lighter weight on MRI to bring in soft-tissue detail.
5. Pass the fused matrix through a logarithmic transform then a power-law (gamma=1.8) transform to keep values off the pure-black/pure-white extremes.
6. Save a side-by-side comparison of CT / MRI / fused output.

Source dataset (swap in real samples before final submission): Heart CT & MRI Dataset — https://www.kaggle.com/datasets/ziya07/heart-ct-and-mri-dataset
