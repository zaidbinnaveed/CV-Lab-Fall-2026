# Task 1: Diagnostic Enhancement of Chest X-Rays

Pipeline (see `xray_enhancement.ipynb`):

1. Load `data/sample_xray.png` as grayscale.
2. Histogram equalization (`cv2.equalizeHist`) — compared raw vs equalized.
3. `cv2.COLORMAP_JET` false-color heatmap of the equalized image.
4. Gray-world color balance shift on the heatmap.
5. Binary threshold (`thresh_val=200`) to mask out everything but the densest tissue.
6. Logarithmic transform on the raw image to expand dark background regions.
7. Power-law (gamma=0.5) transform on the raw image to soften bone contrast.

All intermediate results are saved to `output/`.

Source dataset (swap in real samples before final submission): COVID19+PNEUMONIA+NORMAL Chest X-Ray Image Dataset — https://www.kaggle.com/datasets/sachinkumar413/covid-pneumonia-normal-chest-xray-images
